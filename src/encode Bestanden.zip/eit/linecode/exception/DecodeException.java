package eit.linecode.exception;

import edu.fra.uas.oop.Terminal;

public class DecodeException extends RuntimeException{
	//public DecodeException() {
	//	Terminal.printLine("Wrong data size");
	//}
}
