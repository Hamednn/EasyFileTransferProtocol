package eit.linecode.exception;

public class EndOfPacketException extends RuntimeException{

}
