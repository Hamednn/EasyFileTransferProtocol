package eit.linecode.exception;

public class StartOfStreamException extends RuntimeException{
	String StartOfStreamException (short i) {
		return "Start of Stream "+i+" is incorrect!!!";
	}
}
