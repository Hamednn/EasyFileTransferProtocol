package eit.linecode;

public class Functions {


	/**
	 * cumulative weight of the code will be calculated
	 * 
	 * @param code complete code <br />
	 * @return cumulative weight from the last part of code
	 */
	public int cumulativeWeight(String code) {
		int weight = 0;
		char[] codeToArray = code.toCharArray();
		for (int i = 0; i < codeToArray.length; i++) {
			if (codeToArray[i] == '+') {
				weight++;
			}
			if (codeToArray[i] == '-') {
				weight--;
			}
		}
		if(weight>0)weight=1;
		if(weight<0)weight=0;
		return weight;
		
		
	}
	
	
	/**
	 * the value of the input will inverted
	 * 
	 * @param code the text we want to invert
	 * @return inverted String value from the input-value
	 */

	public static String inverted(String code) {
		char[] codeChar = code.toCharArray();
		for (int i = 0; i < codeChar.length; i++) {
			if (codeChar[i] == '+') {
				codeChar[i] = '-';
				continue;
			}
			if (codeChar[i] == '-') {
				codeChar[i] = '+';
				continue;
			}
		}
		code = String.valueOf(codeChar);
		return code;
	}
	
	
}
