package eit.linecode;
import edu.fra.uas.oop.Terminal;
import eit.linecode.CodeInterface;

/**
 * This class implements the encoder functionality of the 8B/6T encoder
 * 
 */
public class DataEncoder8B6T implements CodeInterface{
	
	private static String dataStream1 = "+-+-+-+-+-+-+--+"; // P4|SOSA|SOSB
	private static String dataStream1End = "++++++------"; // EOP_1|EOP_4
	
	private static String dataStream2 = "+-+-+-+-+-+-+-+--+"; // SOSA|SOSA|SOSB
	private static String dataStream2End = "++++----===="; // EOP_2|EOP_5

	private static String dataStream3 = "+-+-+-+-+-+-+-+-+--+"; // P3|SOSA|SOSA|SOSB
	private static String dataStream3End = "++--==";
	private Functions func= new Functions();

	private static String codeWordsTable = "00 +-00+- 20 00-++- 40 +0+00- 60 0-0++0"
			+ " 01 0+-+-0 21 --+00+ 41 ++00-0 61 00-+0+" + " 02 +-0+-0 22 ++-0+- 42 +0+0-0 62 0-0+0+"
			+ " 03 -0++-0 23 ++-0-+ 43 0++0-0 63 -00+0+" + " 04 -0+0+- 24 00+0-+ 44 0++00- 64 -00++0"
			+ " 05 0+--0+ 25 00+0+- 45 ++0-00 65 00-0++" + " 06 +-0-0+ 26 00-00+ 46 +0+-00 66 0-00++"
			+ " 07 -0+-0+ 27 --+++- 47 0++-00 67 -000++" + " 08 -+00+- 28 -0-++0 48 000+00 68 -+-++0"
			+ " 09 0-++-0 29 --0+0+ 49 000-++ 69 --++0+" + " 0A -+0+-0 2A -0-+0+ 4A 000+-+ 6A -+-+0+"
			+ " 0B +0-+-0 2B 0--+0+ 4B 000++- 6B +--+0+" + " 0C +0-0+- 2C 0--++0 4C 000-+0 6C +--++0"
			+ " 0D 0-+-0+ 2D --00++ 4D 000-0+ 6D --+0++" + " 0E -+0-0+ 2E -0-0++ 4E 000+-0 6E -+-0++"
			+ " 0F +0--0+ 2F 0--0++ 4F 000+0- 6F +--0++" + " 10 +0+--0 30 +-00-+ 50 +0+--+ 70 -++000"
			+ " 11 ++0-0- 31 0+--+0 51 ++0-+- 71 +-+000" + " 12 +0+-0- 32 +-0-+0 52 +0+-+- 72 ++-000"
			+ " 13 0++-0- 33 -0+-+0 53 0++-+- 73 00+000" + " 14 <0++--0 34 -0+0-+ 54 0++--+ 74 -0+000"
			+ " 15 ++00-- 35 0+-+0- 55 ++0+-- 75 0-+000" + " 16 +0+0-- 36 +-0+0- 56 +0++-- 76 +0-000"
			+ " 17 0++0-- 37 -0++0- 57 0+++-- 77 0+-000" + " 18 0+-0+- 38 -+00-+ 58 +++0-- 78 0--+++"
			+ " 19 0+-0-+ 39 0-+-+0 59 +++-0- 79 -0-+++" + " 1A 0+-++- 3A -+0-+0 5A +++--0 7A --0+++"
			+ " 1B 0+-00+ 3B +0--+0 5B ++0--0 7B --0++0" + " 1C 0-+00+ 3C +0-0-+ 5C ++0--+ 7C ++-00-"
			+ " 1D 0-+++- 3D 0-++0- 5D ++000- 7D 00+00-" + " 1E 0-+0-+ 3E -+0+0- 5E --+++0 7E ++---+"
			+ " 1F 0-+0+- 3F +0-+0- 5F 00-++0 7F 00+--+" + " 80 +-+00- A0 0-0++- C0 +-+0+- E0 +-0++-"
			+ " 81 ++-0-0 A1 00-+-+ C1 ++-+-0 E1 0+-+-+" + " 82 +-+0-0 A2 0-0+-+ C2 +-++-0 E2 +-0+-+"
			+ " 83 -++0-0 A3 -00+-+ C3 -+++-0 E3 -0++-+" + " 84 -++00- A4 -00++- C4 -++0+- E4 -0+++-"
			+ " 85 ++--00 A5 00--++ C5 ++--0+ E5 0+--++" + " 86 +-+-00 A6 0-0-++ C6 +-+-0+ E6 +-0-++"
			+ " 87 -++-00 A7 -00-++ C7 -++-0+ E7 -0+-++" + " 88 0+000- A8 -+-++- C8 0+00+- E8 -+0++-"
			+ " 89 00+0-0 A9 --++-+ C9 00++-0 E9 0-++-+" + " 8A 0+00-0 AA -+-+-+ CA 0+0+-0 EA -+0+-+"
			+ " 8B +000-0 AB +--+-+ CB +00+-0 EB +0-+-+" + " 8C +0000- AC +--++- CC +000+- EC +0-++-"
			+ " 8D 00+-00 AD --+-++ CD 00+-0+ ED 0-+-++" + " 8E 0+0-00 AE -+--++ CE 0+0-0+ EE -+0-++"
			+ " 8F +00-00 AF +---++ CF +00-0+ EF +0--++" + " 90 +-+--+ B0 0-000+ D0 +-+0-+ F0 +-000+"
			+ " 91 ++--+- B1 00-0+0 D1 ++--+0 F1 0+-0+0" + " 92 +-+-+- B2 0-00+0 D2 +-+-+0 F2 +-00+0"
			+ " 93 -++-+- B3 -000+0 D3 -++-+0 F3 -0+0+0" + " 94 -++--+ B4 -0000+ D4 -++0-+ F4 -0+00+"
			+ " 95 ++-+-- B5 00-+00 D5 ++-+0- F5 0+-+00" + " 96 +-++-- B6 0-0+00 D6 +-++0- F6 +-0+00"
			+ " 97 -+++-- B7 -00+00 D7 -+++0- F7 -0++00" + " 98 0+0--+ B8 -+-00+ D8 0+00-+ F8 -+000+"
			+ " 99 00+-+- B9 --+0+0 D9 00+-+0 F9 0-+0+0" + " 9A 0+0-+- BA -+-0+0 DA 0+0-+0 FA -+00+0"
			+ " 9B +00-+- BB +--0+0 DB +00-+0 FB +0-0+0" + " 9C +00--+ BC +--00+ DC +000-+ FC +0-00+"
			+ " 9D 00++-- BD --++00 DD 00++0- FD 0-++00" + " 9E 0+0+-- BE -+-+00 DE 0+0+0- FE -+0+00"
			+ " 9F +00+-- BF +--+00 DF +00+0- FF +0-+00";

	private static String[] codeArray = codeWordsTable.split(" ");

	private static int dcBalance1 = 0, dcBalance2 = 0, dcBalance3 = 0;

	/** This function encode the text to the 8B/6T<br />
	 *  if the user need to encode text to the 8B/6T with 3 Datastream can use this function
	 * @param data is the input text, which the user want to encode
	 * @return String[] with 3 elements {<b>DataStream1</b>,<b>DataStream2</b>,<b>DataStream3</b>}
	 */
	
	public String[] encode(byte[] data) {
		dcBalance1=0;
		dcBalance2=0;
		dcBalance3=0;
		String temp1=dataStream1;
		String temp2=dataStream2;
		String temp3=dataStream3;
		
		for (int i = 0; i < data.length; i++) {
			//byte b = data[i];
			int b=Integer.parseInt(String.valueOf(data[i]));
			//int zahll=Integer.parseInt(String.valueOf(b));
			//Terminal.printLine(b);
			if(b<0) {
				b=b+256;
			}
			//Terminal.printLine(b);
			int wordBalance=func.cumulativeWeight(jadid[b]);
			if(i%3==0) {
				if(wordBalance==0){
					temp1=temp1+jadid[b];
					continue;
					
					}
				if(wordBalance==1 && dcBalance1==0){
					dcBalance1=1;
					temp1=temp1+jadid[b];
					continue;
					}
				if(wordBalance==1 && dcBalance1==1){
					dcBalance1=0;
					temp1=temp1+func.inverted(jadid[b]);
					continue;
					}
			}
			if(i%3==1) {
				if(wordBalance==0){
					temp2=temp2+jadid[b];
					continue;
					
					}
				if(wordBalance==1 && dcBalance2==0){
					dcBalance2=1;
					temp2=temp2+jadid[b];
					continue;
					}
				if(wordBalance==1 && dcBalance2==1){
					dcBalance2=0;
					temp2=temp2+func.inverted(jadid[b]);
					continue;
					}
			}
			if(i%3==2) {
				if(wordBalance==0){
					temp3=temp3+jadid[b];
					continue;
					
					}
				if(wordBalance==1 && dcBalance3==0){
					dcBalance3=1;
					temp3=temp3+jadid[b];
					continue;
					}
				if(wordBalance==1 && dcBalance3==1){
					dcBalance3=0;
					temp3=temp3+func.inverted(jadid[b]);
					continue;
					}
			}
		}
		String[] text =new String[3];
		
		if(dcBalance1==0 ) {
			text[0]=temp1+func.inverted(dataStream1End);
		}else {
			text[0]=temp1+dataStream1End;
		}
		
		if(dcBalance2==0 ) {
			text[1]=temp2+func.inverted(dataStream2End);
		}else {
			text[1]=temp2+dataStream2End;
		}
		
		if(dcBalance3==0) {	
			text[2]=temp3+func.inverted(dataStream3End);
		}else {
			text[2]=temp3+dataStream3End;
		}
		return text;
	}
	
}