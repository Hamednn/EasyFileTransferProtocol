package eit.linecode;

import edu.fra.uas.oop.Terminal;
import eit.linecode.exception.StartOfStreamException;





public class DataDecoder8B6T extends Functions implements CodeInterface{
	
	
/*	
	private boolean checkInputSize(String input) {
		if(input.length()%6==0) {
			return true;	 
		 }
		return false;
	}
	
	
	
	private String decodeLine(String input) {
		Terminal.printLine(input);
		int dc=0;
		String[] parts= new String[input.length()/6];
		
		for (int i = 0; i < input.length()-1/6; i++) {	
			String temp= input.substring(0,6);
			//Terminal.printLine(temp);
			parts[i]=temp;
			input=input.substring(6);
		}
		
		int weight=0;
		for (int i = 0; i < parts.length; i++) {
			weight=cumulativeWeight(parts[i]);
			if(dc==0 &&  weight==0) {
				dc=0;
				continue;
			}
			if(dc==0 &&  weight==1) {
				dc=1;
				continue;
			}
			if(dc==1) {
				parts[i]=inverted(parts[i]);
				dc=0;
			}
		}
		
		String text="";
		String end="";
		
		Terminal.printLine(parts.length);
		byte[] teile= new byte[parts.length];
		for(int i=0;i<parts.length;i++) {
			for (int j = 0; j < h.length; j++) {
				if(parts[i].equals(h[j])) {
					text=text+h[j-1];
				}
			}
		}
		
		for (int i = 0; i < text.length()/2; i++) {
			
			
			text=text.substring(0,2);
			
		}
		
		Terminal.printLine(end);
		return text;
	}
	
	
	
	private String deleteEndOfData(String data, int i) {
		if(i==1 || i==2) {
			return data.substring(0,data.length()-12);
		}
		if(i==3) {
			return data.substring(0,data.length()-6);
		}
		
		return data;
	}
	
	
	 public byte[] decode(String[] data) {
		 byte[] letters = {1,2};
		 String input1= data[0];
		 String input2= data[1];
		 String input3= data[2];
		 
		 //String startOfInput1 =dataStream1.substring(0,start1.length());
		 //String startOfInput2 =dataStream2.substring(0,start2.length());
		 //String startOfInput3 =dataStream3.substring(0,start3.length());
		 if(!input1.substring(0,startDataStream1.length()).equals(startDataStream1)) {
			 //TODO Throw Exception Start...
			 Terminal.printError("StartOf1");
		 }
		 else if(!input2.substring(0,startDataStream1.length()).equals(startDataStream2)) {
			//TODO Throw Exception Start...
			 Terminal.printError("StartOf2");
		 }else if(!input3.substring(0,startDataStream1.length()).equals(startDataStream3)) {
			//TODO Throw Exception Start...
			 Terminal.printError("StartOf3");
		 }
		 String input1Data=deleteEndOfData(input1.substring(startDataStream1.length()), 1);
		 String input2Data=deleteEndOfData(input2.substring(startDataStream2.length()), 2);
		 String input3Data=deleteEndOfData(input3.substring(startDataStream3.length()), 3);
		 
		 
		 String[] text=new String[3];
		 if(checkInputSize(input1Data)) {
			 text[0]=decodeLine(input1Data);
		 }
		 
		 if(checkInputSize(input2Data)) {
			 text[1]=decodeLine(input2Data);
		 }
		 if(checkInputSize(input3Data)) {
			 text[2]=decodeLine(input3Data);
		 }
		 for (int j = 0; j < text.length; j++) {
			 	
		}
		 	
		 return letters;
	 }
	
	*/
}
