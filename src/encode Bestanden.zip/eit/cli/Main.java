
package eit.cli;

import eit.linecode.DataDecoder8B6T;
import eit.linecode.DataEncoder8B6T;

import edu.fra.uas.oop.Terminal;



/**
 * the main class of the encode program
 * 
 * @author hamed,Nakhei Nejad for first Java exercise
 */
public class Main {

	/**
	 * is the main function to run the program
	 * 
	 * @param args an array of command-line arguments for the application
	 * @Param input the inputText from user
	 */
	public static void main(String[] args) {
		
		
		String input = "";
		while (true) {
			input = Terminal.readLine();
			
			if (input.contains("encode")) { // control if input is right
				input = input.substring(7); // Delete "encode " from input
				byte[] inputToByte = input.getBytes(); // convert input from String to bytes
				DataEncoder8B6T encodeClass = new DataEncoder8B6T();
				//String[] encodeText = encodeClass.encode(inputToByte); // and encode input to 3 DataStreams
				byte[] b= {-52, 105, -38, 11, 50, -66, 53, -39, -126, 90};
				String[] encodeText = encodeClass.encode(b); // and encode input to 3 DataStreams

					Terminal.printLine("DataStream1: "+encodeText[0]);
					Terminal.printLine("DataStream2: "+encodeText[1]);
					Terminal.printLine("DataStream3: "+encodeText[2]);
				
					continue;
			} else if (input.contains("quit")) { // if the input equals exit, the program is terminated
				
				break;
			}
			
			Terminal.printError("unknown command");
		}
		
		
		DataDecoder8B6T decoderClass= new DataDecoder8B6T();
		String[] i= new String[3];
		i[0]="+-+-+-+-+-+-+--+===+==-++--==+++---++--=--+==+------++++++";
		    //+-+-+-+-+-+-+--+===+==-++--==+++---++--=--+==+------++++++
		    
		i[1]="+-+-+-+-+-+-+-+--+==-=++-++=--+--=+++==--=--+==+----++++====";
		  //  +-+-+-+-+-+-+-+--+==-=++-++=--+--=+++==--=--+==+----++++====
		      
		i[2]="+-+-+-+-+-+-+-+-+--++--++===-++---+===--+==+--++==";
		//    +-+-+-+-+-+-+-+-+--++--++===-++---+===--+==+--++==
		//byte[]letter=decoderClass.decode(i);
		
		//Terminal.printLine(letter[0]);
		
		
		}
	}
		
		
	
